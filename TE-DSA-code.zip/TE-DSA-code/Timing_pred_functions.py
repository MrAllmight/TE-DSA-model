import torch
import random
import numpy
from collections import Counter

######################################################################
# read in the data
# x is the time series
# y is [ci, label], ci is 0 (censored) or 1 (uncensored)

def read_inputs(file,m,ik, fold_flag):
    data_ori = []
    with open(file,'r') as f:
        for line in f:
            tmp = []
            tmp = line.split()
            for i in range(0,len(tmp)):
                tmp[i] = tmp[i].replace('|',' ').split()
                for j in range(0,len(tmp[i])):
                    tmp[i][j] = float(tmp[i][j])
            data_ori.append(tmp)
        data = numpy.zeros((len(data_ori),len(data_ori[0]),len(data_ori[0][1])))
        for i in range(0,len(data_ori)):
            for j in range(0,len(data_ori[i])):
                for k in range(0,len(data_ori[i][j])):
                    data[i][j][k] = data_ori[i][j][k]
        #numpy.random.shuffle(data)

    num_classifiications = m * (1-ik)
    fold_interval = int(0.1 * len(data))
    x = data[:10*fold_interval,1 :(int(m * ik + 1))]
    y = numpy.zeros((len(data),2))
    count_y = []

    for i in range(0, len(data)):
        if data[i][0][0] == -1:
            c = 0
        else:
            c = 1
        y[i][0] = c
        y[i][1] = data[i][0][0]
        count_y.append(data[i][0][0])
    x = x.reshape((10 , fold_interval, len(x[0]), len(x[0][0])))
    y = y[:10*fold_interval]
    y = y.reshape((10, fold_interval, 2))
    ############# cross fold clip
    train_x, train_y, val_x, val_y, test_x, test_y = [], [], [], [], [], []
    val_x = x[fold_flag[0]]
    val_y = y[fold_flag[0]]
    test_x = x[fold_flag[1]]
    test_y = y[fold_flag[1]]
    train_x = numpy.vstack((x[fold_flag[2]],x[fold_flag[3]],x[fold_flag[4]],x[fold_flag[5]],x[fold_flag[6]],x[fold_flag[7]],x[fold_flag[8]],x[fold_flag[9]]))
    train_y = numpy.vstack((y[fold_flag[2]], y[fold_flag[3]], y[fold_flag[4]], y[fold_flag[5]], y[fold_flag[6]],
                            y[fold_flag[7]], y[fold_flag[8]], y[fold_flag[9]]))

    #print('top label rate = ',float(Counter(count_y).most_common()[0][1])/float(len(count_y)))

    train_x_tensor = torch.tensor(train_x,dtype=torch.float32,requires_grad=True)
    train_y_tensor = torch.tensor(train_y, dtype=torch.float32, requires_grad=True)
    val_x_tensor = torch.tensor(val_x, dtype=torch.float32, requires_grad=False)
    val_y_tensor = torch.tensor(val_y, dtype=torch.float32, requires_grad=False)
    test_x_tensor = torch.tensor(test_x, dtype=torch.float32, requires_grad=False)
    test_y_tensor = torch.tensor(test_y,dtype=torch.float32,requires_grad=False)

    return train_x_tensor, train_y_tensor, val_x_tensor, val_y_tensor, test_x_tensor, test_y_tensor

def read_inputs_linear(file,m,ik, fold_flag):
    data_ori = []
    with open(file,'r') as f:
        for line in f:
            tmp = []
            tmp = line.split()
            for i in range(0,len(tmp)):
                tmp[i] = tmp[i].replace('|',' ').split()
                for j in range(0,len(tmp[i])):
                    tmp[i][j] = float(tmp[i][j])
            data_ori.append(tmp)
        data = numpy.zeros((len(data_ori),len(data_ori[0]),len(data_ori[0][1])))
        for i in range(0,len(data_ori)):
            for j in range(0,len(data_ori[i])):
                for k in range(0,len(data_ori[i][j])):
                    data[i][j][k] = data_ori[i][j][k]
        #numpy.random.shuffle(data)

    num_classifiications = m * (1 - ik)
    fold_interval = int(0.1 * len(data))
    x = data[:10 * fold_interval, 1:(int(m * ik + 1))]
    y = numpy.zeros((len(data), 2))
    count_y = []

    for i in range(0, len(data)):
        if data[i][0][0] == -1:
            c = 0
        else:
            c = 1
        y[i][0] = c
        y[i][1] = data[i][0][0]
        count_y.append(data[i][0][0])
    x = x.reshape((10, fold_interval, len(x[0]), len(x[0][0])))
    y = y[:10 * fold_interval]
    y = y.reshape((10, fold_interval, 2))
    ############# cross fold clip
    train_x, train_y, val_x, val_y, test_x, test_y = [], [], [], [], [], []
    val_x = x[fold_flag[0]]
    val_y = y[fold_flag[0]]
    test_x = x[fold_flag[1]]
    test_y = y[fold_flag[1]]
    train_x = numpy.vstack((x[fold_flag[2]], x[fold_flag[3]], x[fold_flag[4]], x[fold_flag[5]], x[fold_flag[6]],
                            x[fold_flag[7]], x[fold_flag[8]], x[fold_flag[9]]))
    train_y = numpy.vstack((y[fold_flag[2]], y[fold_flag[3]], y[fold_flag[4]], y[fold_flag[5]], y[fold_flag[6]],
                            y[fold_flag[7]], y[fold_flag[8]], y[fold_flag[9]]))

    print('top label rate = ',float(Counter(count_y).most_common()[0][1])/float(len(count_y)))

    train_x_tensor = torch.tensor(train_x,dtype=torch.float32,requires_grad=True)
    train_y_tensor = torch.tensor(train_y, dtype=torch.long, requires_grad=False)
    val_x_tensor = torch.tensor(val_x, dtype=torch.float32, requires_grad=False)
    val_y_tensor = torch.tensor(val_y, dtype=torch.long, requires_grad=False)
    test_x_tensor = torch.tensor(test_x, dtype=torch.float32, requires_grad=False)
    test_y_tensor = torch.tensor(test_y,dtype=torch.long,requires_grad=False)

    train_x_tensor = torch.reshape(train_x_tensor,(train_x_tensor.size(0),train_x_tensor.size(1)))
    #train_x_tensor = torch.reshape(train_x_tensor, (train_x_tensor.size(0), train_x_tensor.size(1)))
    val_x_tensor = torch.reshape(val_x_tensor,(val_x_tensor.size(0),val_x_tensor.size(1)))
    #val_x_tensor = torch.reshape(val_x_tensor, (val_x_tensor.size(0), val_x_tensor.size(1)))
    test_x_tensor = torch.reshape(test_x_tensor,(test_x_tensor.size(0),test_x_tensor.size(1)))

    return train_x_tensor, train_y_tensor, val_x_tensor, val_y_tensor, test_x_tensor, test_y_tensor


def read_inputs_drsa_rtonly(file,m,ik, fold_flag):
    data_ori = []
    with open(file, 'r') as f:
        for line in f:
            tmp = []
            tmp = line.split()
            for i in range(0, len(tmp)):
                tmp[i] = tmp[i].replace('|', ' ').split()
                for j in range(0, len(tmp[i])):
                    tmp[i][j] = float(tmp[i][j])
            data_ori.append(tmp)
        data = numpy.zeros((len(data_ori), len(data_ori[0]), int(ik*m)+2))
        for i in range(0, len(data_ori)):
            for j in range(0, len(data_ori[i])):
                for k in range(0, len(data[i][j])-1):
                    data[i][j][k] = data_ori[i][k][0]
                data[i][j][-1] = j-1

        #numpy.random.shuffle(data)

    num_classifiications = m * (1 - ik)
    fold_interval = int(0.1 * len(data))
    x = data[:10 * fold_interval, 1:(int(m * ik + 1)),1:len(data[0][0])]
    y = numpy.zeros((len(data), 2))
    count_y = []

    for i in range(0, len(data)):
        if data[i][0][0] == -1:
            c = 0
        else:
            c = 1
        y[i][0] = c
        y[i][1] = data[i][0][0]
        count_y.append(data[i][0][0])
    x = x.reshape((10, fold_interval, len(x[0]), len(x[0][0])))
    y = y[:10 * fold_interval]
    y = y.reshape((10, fold_interval, 2))
    ############# cross fold clip
    train_x, train_y, val_x, val_y, test_x, test_y = [], [], [], [], [], []
    val_x = x[fold_flag[0]]
    val_y = y[fold_flag[0]]
    test_x = x[fold_flag[1]]
    test_y = y[fold_flag[1]]
    train_x = numpy.vstack((x[fold_flag[2]], x[fold_flag[3]], x[fold_flag[4]], x[fold_flag[5]], x[fold_flag[6]],
                            x[fold_flag[7]], x[fold_flag[8]], x[fold_flag[9]]))
    train_y = numpy.vstack((y[fold_flag[2]], y[fold_flag[3]], y[fold_flag[4]], y[fold_flag[5]], y[fold_flag[6]],
                            y[fold_flag[7]], y[fold_flag[8]], y[fold_flag[9]]))

    print('top label rate = ', float(Counter(count_y).most_common()[0][1]) / float(len(count_y)))

    train_x_tensor = torch.tensor(train_x, dtype=torch.float32, requires_grad=True)
    train_y_tensor = torch.tensor(train_y, dtype=torch.float32, requires_grad=True)
    val_x_tensor = torch.tensor(val_x, dtype=torch.float32, requires_grad=False)
    val_y_tensor = torch.tensor(val_y, dtype=torch.float32, requires_grad=False)
    test_x_tensor = torch.tensor(test_x, dtype=torch.float32, requires_grad=False)
    test_y_tensor = torch.tensor(test_y, dtype=torch.float32, requires_grad=False)

    return train_x_tensor, train_y_tensor, val_x_tensor, val_y_tensor, test_x_tensor, test_y_tensor


def count_correct(threshold, survival, y):
    result = 0
    for i in range(0,survival.size(0)):
        flag = -1
        for j in range(0,survival.size(1)):
            if threshold >= survival[i][j].item():
                flag = j
                break
        if flag == int(y[i][1].item()):
            result += 1
    return result

def find_threshold(survival,y):
    thresholds = numpy.zeros(100)
    thresholds[0] = 0.01
    for i in range(1, len(thresholds)):
        thresholds[i] = thresholds[i-1] + 0.01
    correct = numpy.zeros(len(thresholds))
    for i in range(len(thresholds)):
        correct[i] = count_correct(thresholds[i],survival,y)
    index = numpy.argmax(correct)
    return thresholds[index], correct[index]

def accuracy(threshold, survival,y):
    num = count_correct(threshold, survival,y)
    return float(num)/float(survival.size(0))

def top_3_accuracy(threshold, survival,y):
    result = 0
    for i in range(0, survival.size(0)):
        flag = -1
        for j in range(0, survival.size(1)):
            if threshold >= survival[i][j].item():
                flag = j
                break
        if flag == int(y[i][1].item()) or flag == int(y[i][1].item()+1) or flag == int(y[i][1].item()-1):
            result += 1
    return float(result) / float(survival.size(0))

def top_5_accuracy(threshold, survival,y):
    result = 0
    for i in range(0, survival.size(0)):
        flag = -1
        for j in range(0, survival.size(1)):
            if threshold >= survival[i][j].item():
                flag = j
                break
        if flag == int(y[i][1].item()) or flag == int(y[i][1].item() + 1) or flag == int(y[i][1].item() - 1) or flag == int(y[i][1].item() - 2) or flag == int(y[i][1].item() +2):
            result += 1
    return float(result) / float(survival.size(0))

def get_pred_y(threshold, survival, y):
    ################# get predicted labels and actual labels without censored data
    # output is [ true label, predicted label]
    labels = []
    for i in range(0, survival.size(0)):
        flag = survival.size(1)
        for j in range(0, survival.size(1)):
            if threshold >= survival[i][j].item():
                flag = j
                break
        if y[i][1].item() >=0:
            labels.append([y[i][1].item(), flag])
    return labels

def MSE_MAE(predy):
    mse = 0
    mae = 0
    for i in range(len(predy)):
        d = predy[i][0] - predy[i][1]
        mse += d*d
        mae += abs(d)
    return float(mse)/float(len(predy)), float(mae)/float(len(predy))

def Cindex(predy):
    count = 0
    num = 0
    for i in range(0,len(predy)-1):
        for j in range(i+1,len(predy)):
            if predy[i][0] != predy[j][0]:
                num += 1
                if predy[i][0] >= predy[j][0] and predy[i][1] >= predy[j][1]:
                    count += 1
                elif predy[i][0] <= predy[j][0] and predy[i][1] <= predy[j][1]:
                    count += 1
    return float(count)/float(num)

def ANLP(h, y, device):
    hzi = torch.zeros(h.shape[0], dtype=torch.float32).to(device)
    hz = torch.zeros(h.shape[0], dtype=torch.float32).to(device)
    # hu = torch.zeros(h.shape[0], dtype=torch.float32).to(device)
    hu = torch.log(1 - h)
    for i in range(h.shape[0]):
        if y[i][1].item() < 0:
            zi = h.size(1) - 1
        else:
            zi = int(y[i][1].item())
        hzi[i] = h[i, zi]
        hz[i] = torch.exp(torch.sum(hu[i, :zi]))

    return (-1)*torch.sum(torch.log(torch.mul(hzi,hz))).item()/y.size(0)

################################################ functions for DeepHit
def get_pred_DP(pred, y):
    ################# get predicted labels and actual labels with censored data
    # output is [ true label, predicted label]
    label = torch.argmax(pred, dim=1)
    labels = []
    #print(y[0][1].item(), label[0].item]()#
    for i in range(label.size(0)):
        labels.append([y[i][1].item(),label[i].item()])
    return labels

def delete_cencored_label(label):
    labels = []
    for i in range(len(label)):
        if label[i][1]>=0:
            labels.append(label[i])
    return labels

def accuracy_DP(pred_y):
    num = 0
    for i in range(len(pred_y)):
        if pred_y[i][0] == pred_y[i][1]:
            num += 1
    return float(num)/float(len(pred_y))

def top_3_accuracy_DP(pred_y):
    num = 0
    for i in range(len(pred_y)):
        flag = int(pred_y[i][0])
        if flag == int(pred_y[i][1]) or flag == int(pred_y[i][1]+1) or flag == int(pred_y[i][1]-1):
            num += 1
    return float(num) / float(len(pred_y))

def top_5_accuracy_DP(pred_y):
    num = 0
    for i in range(len(pred_y)):
        flag = int(pred_y[i][0])
        if flag == int(pred_y[i][1]) or flag == int(pred_y[i][1] + 1) or flag == int(
                        pred_y[i][1] - 1) or flag == int(pred_y[i][1] + 2) or flag == int(
                        pred_y[i][1] - 2):
            num += 1
    return float(num) / float(len(pred_y))

def ANLP_DP(f, y, device):
    fzi = torch.zeros(f.size(0), dtype=torch.float32).to(device)
    for i in range(f.size(0)):
        if y[i][1].item() < 0:
            zi = f.size(1) - 1
        else:
            zi = int(y[i][1].item())
        fzi[i] = f[i, zi]

    return (-1)*torch.sum(torch.log(fzi)).item()/y.size(0)


############################################## functions in PreWhen model

def read_inputs_prewhen(file,m,ik,fold_flag):
    data_ori = []
    with open(file,'r') as f:
        for line in f:
            tmp = []
            tmp = line.split()
            for i in range(0,len(tmp)):
                tmp[i] = tmp[i].replace('|',' ').split()
                for j in range(0,len(tmp[i])):
                    tmp[i][j] = float(tmp[i][j])
            data_ori.append(tmp)

        data = numpy.zeros((len(data_ori),len(data_ori[0]),len(data_ori[0][1])))
        for i in range(0,len(data_ori)):
            data[i][0] = data_ori[i][0]
            for j in range(len(data_ori[i])-1, 1, -1):
                data[i][j][0] = data_ori[i][j][0] - data_ori[i][j-1][0]
                #for k in range(len(data_ori[i][j])-1,1,-1):
                    #data[i][j][k] = data_ori[i][j][k] - data_ori[i][j][k-1] - data_ori[i][j][1]

        #numpy.random.shuffle(data)

    fold_interval = int(0.1 * len(data))
    sets_x = data[:10 * fold_interval, 1:]
    y = numpy.zeros((len(data), 2))
    x = numpy.zeros(len(data))
    count_y = []

    for i in range(0, len(data)):
        if data[i][0][0] == -1:
            flag = m-1
            c = 0
        else:
            flag = data[i][0][0]
            c = 1
        x[i] = data[i][int(flag) + 1][0]
        y[i][0] = c
        y[i][1] = data[i][0][0]
        count_y.append(data[i][0][0])

    sets_x = sets_x.reshape((10, fold_interval,len(sets_x[0])))
    x = x[:10*fold_interval]
    x = x.reshape((10, fold_interval))
    y = y[:10 * fold_interval]
    y = y.reshape((10, fold_interval, 2))

    ############# cross fold clip

    val_x = x[fold_flag[0]]
    val_y = y[fold_flag[0]]
    test_x = sets_x[fold_flag[1]]
    test_y = y[fold_flag[1]]
    train_x = numpy.hstack((x[fold_flag[2]], x[fold_flag[3]], x[fold_flag[4]], x[fold_flag[5]], x[fold_flag[6]],
                            x[fold_flag[7]], x[fold_flag[8]], x[fold_flag[9]]))
    train_y = numpy.vstack((y[fold_flag[2]], y[fold_flag[3]], y[fold_flag[4]], y[fold_flag[5]], y[fold_flag[6]],
                            y[fold_flag[7]], y[fold_flag[8]], y[fold_flag[9]]))

    print('top label rate = ',float(Counter(count_y).most_common()[0][1])/float(len(count_y)))

    train_x_tensor = torch.tensor(train_x,dtype=torch.float32,requires_grad=True)
    train_y_tensor = torch.tensor(train_y, dtype=torch.float32, requires_grad=True)
    val_x_tensor = torch.tensor(val_x, dtype=torch.float32, requires_grad=False)
    val_y_tensor = torch.tensor(val_y, dtype=torch.float32, requires_grad=False)
    test_x_tensor = torch.tensor(test_x, dtype=torch.float32, requires_grad=False)
    test_y_tensor = torch.tensor(test_y,dtype=torch.float32,requires_grad=False)

    return train_x_tensor, train_y_tensor, val_x_tensor, val_y_tensor, test_x_tensor, test_y_tensor

######################## readin function for our model with text fusion
def read_text_inputs(file,m,ik, fold_flag):
    data = numpy.load(file)

    fold_interval = int(0.1 * len(data))
    text = data[:10*fold_interval, :(int(m * ik )), :]
    text = text.reshape((10, fold_interval, len(text[0]), len(text[0][0])))

    ############# cross fold clip
    train_text, val_text, test_text = [], [], []
    val_text = text[fold_flag[0]]
    test_text = text[fold_flag[1]]
    train_text = numpy.vstack((text[fold_flag[2]],text[fold_flag[3]],text[fold_flag[4]],text[fold_flag[5]],text[fold_flag[6]],text[fold_flag[7]],text[fold_flag[8]],text[fold_flag[9]]))

    train_text_tensor = torch.tensor(train_text,dtype=torch.float32,requires_grad=True)
    val_text_tensor = torch.tensor(val_text, dtype=torch.float32, requires_grad=False)
    test_text_tensor = torch.tensor(test_text, dtype=torch.float32, requires_grad=False)

    return train_text_tensor, val_text_tensor, test_text_tensor

