import torch
import random
import Timing_pred_functions # import read_inputs
import numpy
import sys
from collections import Counter


######################## output is the hazard function, S(t) is based on chain rule
def training(m_in, ik_in, ht_in, rt_num, one_fold, epo, bac):
    # Device configuration
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    #device = torch.device('cpu')

    # Training Parameters
    m = m_in                  # total time intervals
    ik = ik_in               # Input time intervals
    ht = ht_in                # hotness threshold
    observation_retweet_num = rt_num

    EPOCH = 200
    BACTH_SIZE = bac
    LR = 0.0002
    ALPHA = 0.9
    BETA = 0.1
    RETWEET_THRESHOLD = ht * observation_retweet_num

    # Read-in Data, and shuffle them
    fname= 'datasets-rtonly/pure-time-series_m{}-ob{}-ht{}-rtnum-only.txt'.format(str(m), str(observation_retweet_num), str(ht))
    textname = 'embedded-datasets/embedding-series_m{}-ob{}-ht{}.npy'.format(str(m), str(observation_retweet_num), str(ht))

    train_x, train_y, val_x, val_y, test_x, test_y = Timing_pred_functions.read_inputs(fname,m,ik, one_fold)
    train_text, val_text, test_text = Timing_pred_functions.read_text_inputs(textname,m,ik, one_fold)

    # pre-process data via batch
    train_dataset = torch.utils.data.TensorDataset(train_x, train_y, train_text)
    train_loader = torch.utils.data.DataLoader(dataset = train_dataset,batch_size=BACTH_SIZE,shuffle=True)
    val_x = val_x.to(device)
    val_y = val_y.to(device)
    val_text = val_text.to(device)
    test_x = test_x.to(device)
    test_y = test_y.to(device)
    test_text = test_text.to(device)

    # Network Parameters

    # text fusion parameters
    input_text_size = 50    # num of input text features
    fusion_layer = 1        # fusion part RNN layer num
    fusion_dim = 1          # num of fusion output features

    # prediction model parameters
    input_size = 2 # num of input time series features
    lstm_hidden_size = m*5 # num of output features
    layer_size = 1 # num of rnn layers

    # Network
    class Model(torch.nn.Module):
        def __init__(self, input_size, lstm_hidden_size, m, ik, layer_size, input_text_size,fusion_layer,fusion_dim):
            super(Model, self).__init__()
            # fusion part
            self.fusion_lstm = torch.nn.LSTM(input_size=input_text_size,hidden_size=fusion_dim,num_layers=fusion_layer,batch_first=True)
            #self.fusion_linear = torch.nn.Linear(fusion_dim, input_size=int(m*ik))

            # prediction part
            self.pre_lstm = torch.nn.LSTM(input_size=input_size,hidden_size=lstm_hidden_size,num_layers=layer_size,batch_first=True)
            self.pre_norm1 = torch.nn.BatchNorm1d(lstm_hidden_size)
            self.pre_linear = torch.nn.Linear(lstm_hidden_size,m)
            #self.pre_norm2 = torch.nn.BatchNorm1d(m)
            #self.softmax = torch.nn.Softmax(dim=1)

        def forward(self, x, text):
            h0 = torch.zeros(layer_size, x.size(0), lstm_hidden_size).to(device)
            c0 = torch.zeros(layer_size, x.size(0), lstm_hidden_size).to(device)
            fusion_h0 = torch.zeros(layer_size, text.size(0), fusion_dim).to(device)
            fusion_c0 = torch.zeros(layer_size, text.size(0), fusion_dim).to(device)

            # text fusion
            text, _ = self.fusion_lstm(text, (fusion_h0, fusion_c0))
            x = torch.cat((x,text), dim=2)

            # prediction
            out, _ = self.pre_lstm(x, (h0,c0))
            out = self.pre_norm1(out[:,-1,:])
    ################### Decode the hidden state of the last time step
            out = self.pre_linear(out)
            #out = self.norm2(out)
            out = torch.sigmoid(out)

            return out

    model = Model(input_size, lstm_hidden_size, m, ik, layer_size, input_text_size,fusion_layer,fusion_dim).to(device)

    # Loss and Opt
    ################################### this loss uses prob chain eq of S(t)
    class chainLoss(torch.nn.Module):
        def __init__(self):
            super(chainLoss, self).__init__()

        def forward(self, h, y, alpha, beta):
            #beta = 0.5
            # hzi is the selected hizi, hz is the sum till zi, ht is the sum of all
            hzi = torch.zeros(h.shape[0],dtype=torch.float32).to(device)
            hz = torch.zeros(h.shape[0], dtype=torch.float32).to(device)
            hu = torch.log(1-h)
            for i in range(h.shape[0]):
                if y[i][1].item()<0:
                    zi = h.size(1)-1
                else:
                    zi = int(y[i][1].item())
                hzi[i] = torch.log(h[i, zi])
                hz[i] = torch.sum(hu[i,:zi])
            ht = torch.sum(hu[:,:-1],dim=1)
            c = y[:,0].float()

            #hzi, hz, ht is [1, bact_size]
            # uncensored data c=1, censored data c=0
            cost = (-1) * torch.sum(
                alpha * (torch.mul(c, hzi) + torch.mul(c, hz)) + beta * (torch.mul(c, hz) + torch.mul(1 - c, ht)))
            #cost = (-1) * torch.sum(torch.mul(c, hzi) + torch.mul(c, hz) + torch.mul(1 - c, ht))
            return cost

    criterion = chainLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=LR)

    # train the model
    total_step = len(train_loader)
    #pre_val_loss = 9999

    for epoch in range(EPOCH):
        loss_value = 0
        for step, (batch_x, batch_y, batch_text) in enumerate(train_loader):
            batch_x = batch_x.to(device)
            batch_y = batch_y.to(device)
            batch_text = batch_text.to(device)

            #print('Epoch:', epoch, '|Step:', step, '|batch_x:',batch_x.numpy(), '|batch_y', batch_y.numpy())
            # Forward pass
            outputs = model(batch_x, batch_text)
            #print(outputs[0])
            loss = criterion(outputs, batch_y,ALPHA,BETA)
            loss_value += loss.item()

            # Backward and optimize
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            # show loss
            #if (step) % 10 == 0:
                #print('Epoch [{}/{}], Step [{}/{}], Loss: {:.4f}'.format(epoch, EPOCH, step , total_step, loss.item()))

        #if (epoch+1) % 1 == 0:
            #with torch.no_grad():
                #val_loss = criterion(model(val_x, val_text), val_y,ALPHA,BETA)
                #print('Epoch [{}/{}], train-Loss: {:.2f}, val-Loss: {:.2f}'.format(epoch + 1, EPOCH, loss_value, val_loss.item()))

        if (epoch + 1) == epo:
        #if pre_val_loss < val_loss:
        #if (epoch + 1)%5 == 0:
        # test the model
            with torch.no_grad():
                ############ find the threshold in validation set
                val_out = model(val_x, val_text)
                val_survival = torch.zeros(val_out.size()).to(device)
                for i in range(val_out.size(0)):
                    for j in range(val_out.size(1)):
                        val_survival[i][j] = torch.exp(torch.sum(torch.log(1-val_out[i,:j])))
                threshold, count = Timing_pred_functions.find_threshold(val_survival,val_y)
                #print('Validation set:')
                #print('Correct [{}/{}], threshold= {:.4f}'.format(int(count), val_survival.size(0), threshold))

                ################# use the threshold evaluating in test set
                test_out = model(test_x, test_text)
                test_survival = torch.zeros(test_out.size()).to(device)
                for i in range(test_out.size(0)):
                    for j in range(test_out.size(1)):
                        test_survival[i][j] = torch.exp(torch.sum(torch.log(1 - test_out[i, :j])))

                acc = Timing_pred_functions.accuracy(threshold, test_survival, test_y)
                #acc = 1
                acc3 = Timing_pred_functions.top_3_accuracy(threshold, test_survival, test_y)
                acc5 = Timing_pred_functions.top_5_accuracy(threshold, test_survival, test_y)
                #print('Test set:')
                #print('Total [{}], threshold= {:.2f}, Accurracy = {:.4f}, top-3-Acc = {:.4f}, top-5-Acc = {:.4f}'.format(test_survival.size(0),threshold,acc,acc3,acc5))

                pred_y = Timing_pred_functions.get_pred_y(threshold, test_survival, test_y)
                mse, mae = Timing_pred_functions.MSE_MAE(pred_y)
                cind = Timing_pred_functions.Cindex(pred_y)
                anlog_prob = Timing_pred_functions.ANLP(test_out, test_y, device)

                #print('MSE = {:.2f}, MAE = {:.2f}, C-index = {:.4f}, ANLP = {:.4f}'.format(mse, mae, cind, anlog_prob))
            break
        #pre_val_loss = val_loss
    return [acc, acc3, acc5, mse, mae, cind, anlog_prob]


# train the model
# m_in, ik_in, ht_in, rt_num
M_num = 20
RT_num = 100
train_paras = [[M_num, 0.6, 0.85, RT_num]]

# 1st is the val set index, 2nd is the test set index, the rest are the train set index
fold = [[0,1,2,3,4,5,6,7,8,9],
        [1,2,0,3,4,5,6,7,8,9],
        [2,3,0,1,4,5,6,7,8,9],
        [3,4,0,1,2,5,6,7,8,9],
        [4,5,0,1,2,3,6,7,8,9],
        [5,6,0,1,2,3,4,7,8,9],
        [6,7,0,1,2,3,4,5,8,9],
        [7,8,0,1,2,3,4,5,6,9],
        [8,9,0,1,2,3,4,5,6,7],
        [9,0,1,2,3,4,5,6,7,8]]
#fold = [[0,1,2,3,4,5,6,7,8,9]]

in_epo = input("input the training epoch: ")
in_bac = input("input the training bacth size: ")
in_epo = int(in_epo)
in_bac = int(in_bac)

for i in range(len(train_paras)):
    results = []
    for k in range(len(fold)):
        print('Running Ours-withtext, paras: [{}\{}], fold[{}\{}]'.format(str(i),str(len(train_paras)),str(k),str(len(fold))))
        results.append(training(train_paras[i][0],train_paras[i][1],train_paras[i][2],train_paras[i][3],fold[k], in_epo, in_bac))
    t_results = torch.tensor(results)
    ave_result = torch.sum(t_results, dim=0)/float(len(fold))
    line = 'Accurracy = {:.4f}, top-3-Acc = {:.4f}, top-5-Acc = {:.4f}, MSE = {:.4f}, MAE = {:.4f}, C-index = {:.4f}, ANLP = {:.4f}'.format(ave_result[0].item(), ave_result[1].item(),ave_result[2].item(),ave_result[3].item(),ave_result[4].item(),ave_result[5].item(),ave_result[6].item())
    with open('Ours-withtext-results-m{}-ob{}.txt'.format(M_num, RT_num), 'a') as wf:
        wf.write('m={}, ht={}, ik={}'.format(M_num, train_paras[i][2], train_paras[i][1])+'\n')
        wf.write(line+'\n')


# Save the model checkpoint
#torch.save(model.state_dict(), 'model.ckpt')
